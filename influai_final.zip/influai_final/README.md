# InfluAI — Manager IA pour Influenceurs

Agent IA complet pour gérer les réseaux sociaux (Instagram, TikTok, YouTube).
Propulsé par Claude (Anthropic).

## 🚀 Déploiement sur Vercel (5 minutes)

### Méthode 1 : GitHub + Vercel (recommandée)

1. **Créez un repo GitHub** :
   - Allez sur github.com → New repository → "influai"
   - Uploadez tous ces fichiers

2. **Déployez sur Vercel** :
   - Allez sur vercel.com → "Add New Project"
   - Importez votre repo GitHub
   - Cliquez "Deploy" → Votre lien est prêt ! 🎉

3. **Partagez le lien** avec vos clients :
   - Exemple : `https://influai-votreprenom.vercel.app`
   - Chaque client entre sa propre clé API Anthropic

### Méthode 2 : Vercel CLI

```bash
npm i -g vercel
vercel
```

## 🔑 Clé API pour vos clients

Chaque client a besoin de sa propre clé API Anthropic :
- Gratuit pour commencer : console.anthropic.com
- ~$5-15/mois pour un usage intensif

## 📱 Fonctionnalités

- ✉ **Boîte de réception** : Lit et répond aux DMs/commentaires avec l'IA
- ✦ **Créateur de contenu** : Génère posts, légendes, descriptions
- ⚙ **Automatisation** : Règles pour réponses auto, filtrage spam
- ◈ **Statistiques** : Suivi de l'activité de l'agent

## 🔒 Sécurité

La clé API est stockée dans le navigateur du client (localStorage).
Elle n'est jamais envoyée sur un serveur tiers.
