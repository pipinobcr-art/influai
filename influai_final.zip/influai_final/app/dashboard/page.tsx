'use client'
import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/navigation'

interface Config {
  name: string
  handle: string
  niche: string
  tone: string
  bio: string
  apiKey: string
  platforms: string[]
}

interface Message {
  id: number
  sender: string
  platform: string
  text: string
  time: string
  unread: boolean
  category?: string
  priority?: string
  aiReply?: string
  status: 'pending' | 'replied' | 'ignored'
}

const DEMO_MESSAGES: Message[] = [
  { id: 1, sender: 'marie_c', platform: 'Instagram', text: 'Bonjour ! Je t\'adore tellement !! Tu peux me dire quelle crème tu utilises ? Ça fait des semaines que je cherche 😍', time: '2min', unread: true, status: 'pending' },
  { id: 2, sender: 'fitness_coach_max', platform: 'TikTok', text: 'Incroyable cette vidéo ! Est-ce que tu fais des coachings en ligne ? Je voudrais apprendre ta méthode', time: '7min', unread: true, status: 'pending' },
  { id: 3, sender: 'brand_lumiere', platform: 'Instagram', text: 'Bonjour ! Nous représentons la marque Lumière et aimerions vous proposer une collaboration rémunérée pour notre nouvelle collection. Budget disponible 2000€. Vous êtes disponible pour un call ?', time: '15min', unread: true, status: 'pending', category: 'collaboration', priority: 'high' },
  { id: 4, sender: 'julia_fan2024', platform: 'YouTube', text: 'Cette vidéo m\'a tellement motivée, je l\'ai regardée 3 fois ! Merci pour tout ce que tu fais, tu changes des vies vraiment ❤️', time: '32min', unread: false, status: 'pending' },
  { id: 5, sender: 'thomas_b', platform: 'TikTok', text: 'Bonne vidéo mais t\'as pas sourcé tes infos là... un peu décevant pour quelqu\'un qui se dit expert', time: '1h', unread: false, status: 'pending' },
  { id: 6, sender: 'pr_agence_presse', platform: 'Instagram', text: 'Bonjour, nous sommes l\'agence RP de plusieurs grandes marques. Nous cherchons des visages pour une campagne nationale. Votre profil nous intéresse fortement.', time: '2h', unread: false, status: 'pending', category: 'media_press', priority: 'high' },
  { id: 7, sender: 'lea_style', platform: 'Instagram', text: 'Tu peux faire un haul mode pour le printemps ? J\'adore quand tu fais ça 🌸', time: '3h', unread: false, status: 'pending' },
]

type TabType = 'inbox' | 'generate' | 'auto' | 'stats'

export default function Dashboard() {
  const router = useRouter()
  const [config, setConfig] = useState<Config | null>(null)
  const [messages, setMessages] = useState<Message[]>(DEMO_MESSAGES)
  const [selectedMsg, setSelectedMsg] = useState<Message | null>(null)
  const [tab, setTab] = useState<TabType>('inbox')
  const [replyText, setReplyText] = useState('')
  const [tone, setTone] = useState('chaleureux')
  const [aiLoading, setAiLoading] = useState(false)
  const [analyzing, setAnalyzing] = useState<number | null>(null)

  // Content generator
  const [genPlatform, setGenPlatform] = useState('Instagram')
  const [genType, setGenType] = useState('Post avec légende')
  const [genIdea, setGenIdea] = useState('')
  const [genStyle, setGenStyle] = useState('Authentique & personnel')
  const [genResult, setGenResult] = useState('')
  const [genLoading, setGenLoading] = useState(false)

  // Auto rules
  const [rules, setRules] = useState({ auto_reply_common: true, reply_positive: true, filter_spam: true, schedule: false, alert_collab: true })

  useEffect(() => {
    const saved = localStorage.getItem('influai_config')
    if (!saved) { router.push('/setup'); return }
    setConfig(JSON.parse(saved))
  }, [router])

  const callAgent = useCallback(async (action: string, extra: Record<string, unknown> = {}) => {
    const res = await fetch('/api/agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ config, action, ...extra })
    })
    const data = await res.json()
    if (data.error) throw new Error(data.error)
    return data.result as string
  }, [config])

  async function analyzeMessage(msg: Message) {
    if (msg.category || analyzing === msg.id) return
    setAnalyzing(msg.id)
    try {
      const raw = await callAgent('analyze_message', { message: msg.text, sender: msg.sender, platform: msg.platform })
      let result: { category?: string; priority?: string } = {}
      try { result = JSON.parse(raw) } catch { result = { category: 'other', priority: 'medium' } }
      setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, category: result.category, priority: result.priority } : m))
      setSelectedMsg(prev => prev?.id === msg.id ? { ...prev, category: result.category, priority: result.priority } : prev)
    } catch { /* silent */ }
    setAnalyzing(null)
  }

  async function generateReply() {
    if (!selectedMsg || !config) return
    setAiLoading(true)
    try {
      const result = await callAgent('reply', {
        message: selectedMsg.text,
        sender: selectedMsg.sender,
        platform: selectedMsg.platform,
        tone
      })
      setReplyText(result)
    } catch (e) {
      setReplyText('Erreur: ' + (e as Error).message)
    }
    setAiLoading(false)
  }

  async function generateContent() {
    if (!genIdea || !config) return
    setGenLoading(true)
    setGenResult('')
    try {
      const result = await callAgent('generate_content', {
        contentType: genType,
        platform: genPlatform,
        idea: genIdea,
        style: genStyle
      })
      setGenResult(result)
    } catch (e) {
      setGenResult('Erreur: ' + (e as Error).message)
    }
    setGenLoading(false)
  }

  function sendReply() {
    if (!replyText || !selectedMsg) return
    setMessages(prev => prev.map(m => m.id === selectedMsg.id ? { ...m, status: 'replied', unread: false, aiReply: replyText } : m))
    setSelectedMsg(null)
    setReplyText('')
  }

  function selectMsg(msg: Message) {
    setSelectedMsg(msg)
    setReplyText('')
    setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, unread: false } : m))
    analyzeMessage(msg)
  }

  function ignoreMsg(id: number) {
    setMessages(prev => prev.map(m => m.id === id ? { ...m, status: 'ignored' } : m))
    if (selectedMsg?.id === id) setSelectedMsg(null)
  }

  if (!config) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg)', color: 'var(--text2)', fontSize: '14px' }}>
      Chargement de votre IA...
    </div>
  )

  const unreadCount = messages.filter(m => m.unread).length
  const pendingCount = messages.filter(m => m.status === 'pending').length

  const inp: React.CSSProperties = { width: '100%', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', padding: '10px 12px', fontSize: '13px', color: 'var(--text)', outline: 'none', fontFamily: 'inherit' }
  const btnPurple: React.CSSProperties = { background: 'var(--purple)', color: 'white', border: 'none', borderRadius: '8px', padding: '10px 18px', fontSize: '13px', fontWeight: 500, cursor: 'pointer', fontFamily: 'inherit' }
  const btnGhost: React.CSSProperties = { background: 'transparent', color: 'var(--text2)', border: '1px solid var(--border)', borderRadius: '8px', padding: '10px 18px', fontSize: '13px', cursor: 'pointer', fontFamily: 'inherit' }

  const catColors: Record<string, string> = { collaboration: 'var(--yellow)', media_press: 'var(--yellow)', spam: 'var(--red)', fan_positive: 'var(--green)', complaint: 'var(--red)', dm_question: 'var(--purple2)', other: 'var(--text3)' }
  const catLabels: Record<string, string> = { collaboration: '🤝 Colla', media_press: '📰 Presse', spam: '🚫 Spam', fan_positive: '❤️ Fan', complaint: '⚠️ Plainte', dm_question: '❓ Question', other: '💬 Autre' }

  return (
    <div style={{ display: 'flex', height: '100vh', background: 'var(--bg)', overflow: 'hidden' }}>
      {/* Sidebar */}
      <aside style={{ width: '220px', background: 'var(--bg2)', borderRight: '1px solid var(--border)', display: 'flex', flexDirection: 'column', padding: '16px 0', flexShrink: 0 }}>
        <div style={{ padding: '0 16px 20px', borderBottom: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
            <span style={{ width: '8px', height: '8px', background: 'var(--purple)', borderRadius: '50%' }} />
            <span style={{ fontSize: '14px', fontWeight: 600 }}>InfluAI</span>
          </div>
          <div style={{ fontSize: '12px', color: 'var(--text2)' }}>{config.name}</div>
          <div style={{ fontSize: '11px', color: 'var(--text3)', marginTop: '2px' }}>{config.handle}</div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', marginTop: '8px', background: 'var(--green-bg)', border: '1px solid rgba(52,211,153,0.2)', borderRadius: '10px', padding: '3px 8px', fontSize: '11px', color: 'var(--green)' }}>
            <span style={{ width: '5px', height: '5px', background: 'var(--green)', borderRadius: '50%' }} />
            IA active
          </div>
        </div>

        <nav style={{ flex: 1, padding: '12px 8px' }}>
          {([
            { key: 'inbox', icon: '✉', label: 'Messages', badge: unreadCount },
            { key: 'generate', icon: '✦', label: 'Créer contenu', badge: 0 },
            { key: 'auto', icon: '⚙', label: 'Automatisation', badge: 0 },
            { key: 'stats', icon: '◈', label: 'Statistiques', badge: 0 },
          ] as {key: TabType, icon: string, label: string, badge: number}[]).map(item => (
            <button
              key={item.key}
              onClick={() => setTab(item.key)}
              style={{ display: 'flex', alignItems: 'center', gap: '10px', width: '100%', padding: '9px 10px', borderRadius: '8px', border: 'none', cursor: 'pointer', fontSize: '13px', fontFamily: 'inherit', background: tab === item.key ? 'var(--bg3)' : 'transparent', color: tab === item.key ? 'var(--text)' : 'var(--text2)', fontWeight: tab === item.key ? 500 : 400, marginBottom: '2px', textAlign: 'left' }}
            >
              <span style={{ width: '16px', textAlign: 'center' }}>{item.icon}</span>
              <span style={{ flex: 1 }}>{item.label}</span>
              {item.badge > 0 && <span style={{ background: 'var(--purple)', color: 'white', fontSize: '10px', padding: '2px 6px', borderRadius: '10px' }}>{item.badge}</span>}
            </button>
          ))}
        </nav>

        <div style={{ padding: '12px 16px', borderTop: '1px solid var(--border)' }}>
          <button onClick={() => { localStorage.removeItem('influai_config'); router.push('/setup') }} style={{ ...btnGhost, width: '100%', fontSize: '12px', padding: '8px' }}>⚙ Paramètres</button>
        </div>
      </aside>

      {/* Main content */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
        {/* Top bar */}
        <header style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--bg2)', flexShrink: 0 }}>
          <div>
            <div style={{ fontSize: '15px', fontWeight: 600 }}>
              {tab === 'inbox' && 'Boîte de réception'}
              {tab === 'generate' && 'Créateur de contenu IA'}
              {tab === 'auto' && 'Règles d\'automatisation'}
              {tab === 'stats' && 'Statistiques'}
            </div>
            <div style={{ fontSize: '12px', color: 'var(--text2)', marginTop: '1px' }}>
              {tab === 'inbox' && `${pendingCount} messages en attente`}
              {tab === 'generate' && 'Générez du contenu pour tous vos réseaux'}
              {tab === 'auto' && 'Configurez ce que l\'IA fait automatiquement'}
              {tab === 'stats' && 'Performance de votre agent IA'}
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'var(--purple-bg)', border: '1px solid var(--purple-border)', borderRadius: '20px', padding: '6px 12px', fontSize: '12px', color: 'var(--purple2)' }}>
            ✦ Propulsé par Claude
          </div>
        </header>

        {/* INBOX TAB */}
        {tab === 'inbox' && (
          <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
            {/* Message list */}
            <div style={{ width: '340px', borderRight: '1px solid var(--border)', display: 'flex', flexDirection: 'column', overflow: 'hidden', flexShrink: 0 }}>
              <div style={{ flex: 1, overflowY: 'auto', padding: '12px' }}>
                {messages.filter(m => m.status !== 'ignored').map(msg => (
                  <div
                    key={msg.id}
                    onClick={() => selectMsg(msg)}
                    style={{
                      padding: '12px', borderRadius: '10px', cursor: 'pointer', marginBottom: '6px',
                      background: selectedMsg?.id === msg.id ? 'var(--bg3)' : 'transparent',
                      border: selectedMsg?.id === msg.id ? '1px solid var(--border2)' : '1px solid transparent',
                      transition: 'all 0.1s',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '5px' }}>
                      {msg.unread && <span style={{ width: '6px', height: '6px', background: 'var(--purple)', borderRadius: '50%', flexShrink: 0 }} />}
                      <span style={{ fontSize: '12px', fontWeight: 500 }}>{msg.sender}</span>
                      <span style={{ fontSize: '10px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '4px', padding: '1px 6px', color: 'var(--text2)', marginLeft: 'auto' }}>{msg.platform}</span>
                    </div>
                    <div style={{ fontSize: '12px', color: 'var(--text2)', lineHeight: 1.5, overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' }}>
                      {msg.text}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '6px' }}>
                      <span style={{ fontSize: '11px', color: 'var(--text3)' }}>{msg.time}</span>
                      {msg.status === 'replied' && <span style={{ fontSize: '10px', color: 'var(--green)' }}>✓ Répondu</span>}
                      {msg.category && <span style={{ fontSize: '10px', color: catColors[msg.category] }}>{catLabels[msg.category]}</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Message detail + reply */}
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
              {selectedMsg ? (
                <>
                  <div style={{ flex: 1, overflowY: 'auto', padding: '24px' }}>
                    {/* Message header */}
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: '14px', marginBottom: '20px' }}>
                      <div style={{ width: '44px', height: '44px', borderRadius: '50%', background: 'var(--purple-bg)', border: '1px solid var(--purple-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px', fontWeight: 600, color: 'var(--purple2)', flexShrink: 0 }}>
                        {selectedMsg.sender[0].toUpperCase()}
                      </div>
                      <div>
                        <div style={{ fontWeight: 500 }}>@{selectedMsg.sender}</div>
                        <div style={{ fontSize: '12px', color: 'var(--text2)', marginTop: '2px' }}>{selectedMsg.platform} · {selectedMsg.time}</div>
                        {analyzing === selectedMsg.id && <div style={{ fontSize: '11px', color: 'var(--purple2)', marginTop: '4px' }}>✦ Analyse IA en cours...</div>}
                        {selectedMsg.category && (
                          <div style={{ marginTop: '6px', display: 'flex', gap: '6px' }}>
                            <span style={{ fontSize: '11px', background: 'var(--bg3)', border: `1px solid var(--border)`, borderRadius: '6px', padding: '3px 8px', color: catColors[selectedMsg.category] }}>{catLabels[selectedMsg.category]}</span>
                            {selectedMsg.priority === 'high' && <span style={{ fontSize: '11px', background: 'var(--yellow-bg)', border: '1px solid rgba(251,191,36,0.2)', borderRadius: '6px', padding: '3px 8px', color: 'var(--yellow)' }}>⚡ Prioritaire</span>}
                          </div>
                        )}
                      </div>
                    </div>

                    <div style={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '12px 12px 12px 4px', padding: '16px', marginBottom: '24px', fontSize: '14px', lineHeight: 1.7 }}>
                      {selectedMsg.text}
                    </div>

                    {/* Reply area */}
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
                        <span style={{ fontSize: '13px', color: 'var(--text2)' }}>Votre réponse</span>
                        <select value={tone} onChange={e => setTone(e.target.value)} style={{ ...inp, width: 'auto', padding: '6px 10px', fontSize: '12px' }}>
                          <option value="chaleureux">Ton chaleureux</option>
                          <option value="professionnel">Professionnel</option>
                          <option value="fun">Fun & décontracté</option>
                          <option value="bref">Bref & direct</option>
                        </select>
                      </div>
                      <textarea
                        style={{ ...inp, height: '110px', resize: 'none', lineHeight: 1.6 }}
                        value={replyText}
                        onChange={e => setReplyText(e.target.value)}
                        placeholder="Écrivez votre réponse ou générez-en une avec l'IA..."
                      />
                      <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
                        <button style={btnPurple} onClick={generateReply} disabled={aiLoading}>
                          {aiLoading ? (
                            <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                              <span style={{ width: '12px', height: '12px', border: '2px solid rgba(255,255,255,0.3)', borderTopColor: 'white', borderRadius: '50%', animation: 'spin 0.8s linear infinite', display: 'inline-block' }} />
                              Génération...
                            </span>
                          ) : '✦ Générer avec l\'IA'}
                        </button>
                        <button style={btnPurple} onClick={sendReply} disabled={!replyText}>Envoyer ↗</button>
                        <button style={btnGhost} onClick={() => ignoreMsg(selectedMsg.id)}>Ignorer</button>
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '12px', color: 'var(--text3)' }}>
                  <span style={{ fontSize: '32px' }}>✉</span>
                  <span style={{ fontSize: '14px' }}>Sélectionnez un message pour y répondre</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* GENERATE TAB */}
        {tab === 'generate' && (
          <div style={{ flex: 1, overflowY: 'auto', padding: '24px', maxWidth: '680px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div>
                <label style={{ fontSize: '12px', color: 'var(--text2)', display: 'block', marginBottom: '8px' }}>Plateforme</label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  {['Instagram', 'TikTok', 'YouTube'].map(p => (
                    <button key={p} onClick={() => setGenPlatform(p)} style={{ padding: '8px 16px', borderRadius: '20px', fontSize: '13px', cursor: 'pointer', border: genPlatform === p ? '1px solid var(--purple)' : '1px solid var(--border)', background: genPlatform === p ? 'var(--purple-bg)' : 'transparent', color: genPlatform === p ? 'var(--purple2)' : 'var(--text2)', fontFamily: 'inherit' }}>{p}</button>
                  ))}
                </div>
              </div>

              <div>
                <label style={{ fontSize: '12px', color: 'var(--text2)', display: 'block', marginBottom: '8px' }}>Type de contenu</label>
                <select value={genType} onChange={e => setGenType(e.target.value)} style={inp}>
                  <option>Post avec légende</option>
                  <option>Story engageante</option>
                  <option>Reel / Short description + hook</option>
                  <option>Annonce collaboration</option>
                  <option>Contenu sponsorisé</option>
                  <option>Réponse aux commentaires fréquents</option>
                </select>
              </div>

              <div>
                <label style={{ fontSize: '12px', color: 'var(--text2)', display: 'block', marginBottom: '8px' }}>Votre idée</label>
                <textarea style={{ ...inp, height: '80px', resize: 'none', lineHeight: 1.6 }} value={genIdea} onChange={e => setGenIdea(e.target.value)} placeholder="Ex: Partager ma routine matinale, annoncer une collab avec Zara, montrer mes coulisses..." />
              </div>

              <div>
                <label style={{ fontSize: '12px', color: 'var(--text2)', display: 'block', marginBottom: '8px' }}>Style de voix</label>
                <select value={genStyle} onChange={e => setGenStyle(e.target.value)} style={inp}>
                  <option>Authentique & personnel</option>
                  <option>Inspirant & motivant</option>
                  <option>Fun & humoristique</option>
                  <option>Expert & éducatif</option>
                  <option>Lifestyle & aspirationnel</option>
                </select>
              </div>

              <button style={btnPurple} onClick={generateContent} disabled={!genIdea || genLoading}>
                {genLoading ? '✦ Génération en cours...' : '✦ Générer le contenu'}
              </button>

              {genResult && (
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <label style={{ fontSize: '12px', color: 'var(--text2)' }}>Contenu généré</label>
                    <button onClick={() => navigator.clipboard.writeText(genResult)} style={{ ...btnGhost, fontSize: '11px', padding: '5px 10px' }}>⎘ Copier</button>
                  </div>
                  <div style={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '10px', padding: '16px', fontSize: '13px', lineHeight: 1.8, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                    {genResult}
                  </div>
                  <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
                    <button style={btnPurple} onClick={generateContent}>↻ Regénérer</button>
                    <button style={{ ...btnGhost, color: 'var(--green)', borderColor: 'rgba(52,211,153,0.3)' }}>📅 Planifier la publication</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* AUTO TAB */}
        {tab === 'auto' && (
          <div style={{ flex: 1, overflowY: 'auto', padding: '24px', maxWidth: '600px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {[
                { key: 'auto_reply_common', icon: '✉', title: 'Réponses automatiques aux questions fréquentes', desc: 'L\'IA répond aux DMs courants sans votre intervention' },
                { key: 'reply_positive', icon: '❤', title: 'Répondre aux commentaires positifs', desc: 'Remerciements et encouragements automatiques' },
                { key: 'filter_spam', icon: '🚫', title: 'Filtrer et ignorer les spams', desc: 'Détection et suppression des messages non pertinents' },
                { key: 'alert_collab', icon: '⚡', title: 'Alertes pour les opportunités importantes', desc: 'Collaborations, presse, partenariats — notification immédiate' },
                { key: 'schedule', icon: '📅', title: 'Publication automatique planifiée', desc: 'Poster aux meilleures heures d\'engagement' },
              ].map(rule => (
                <div key={rule.key} style={{ display: 'flex', alignItems: 'center', gap: '16px', padding: '16px', background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: '10px' }}>
                  <span style={{ fontSize: '20px', width: '24px', textAlign: 'center' }}>{rule.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: '14px', fontWeight: 500 }}>{rule.title}</div>
                    <div style={{ fontSize: '12px', color: 'var(--text2)', marginTop: '2px' }}>{rule.desc}</div>
                  </div>
                  <button
                    onClick={() => setRules(prev => ({ ...prev, [rule.key]: !prev[rule.key as keyof typeof rules] }))}
                    style={{ width: '40px', height: '22px', borderRadius: '11px', border: 'none', cursor: 'pointer', transition: 'background 0.2s', background: rules[rule.key as keyof typeof rules] ? 'var(--purple)' : 'var(--bg3)', position: 'relative', flexShrink: 0 }}
                  >
                    <span style={{ position: 'absolute', top: '3px', width: '16px', height: '16px', background: 'white', borderRadius: '50%', transition: 'left 0.2s', left: rules[rule.key as keyof typeof rules] ? '21px' : '3px' }} />
                  </button>
                </div>
              ))}
            </div>
            <div style={{ marginTop: '20px', padding: '16px', background: 'var(--purple-bg)', border: '1px solid var(--purple-border)', borderRadius: '10px', fontSize: '13px', color: 'var(--text2)', lineHeight: 1.7 }}>
              ✦ <strong style={{ color: 'var(--purple2)' }}>L&apos;IA apprend votre style.</strong> Plus vous validez ou corrigez ses réponses, plus elle vous ressemble. Après 50 interactions, elle atteint 95% de précision.
            </div>
          </div>
        )}

        {/* STATS TAB */}
        {tab === 'stats' && (
          <div style={{ flex: 1, overflowY: 'auto', padding: '24px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px', marginBottom: '24px' }}>
              {[
                { val: messages.filter(m => m.status === 'replied').length, label: 'Réponses envoyées', sub: 'Cette session', color: 'var(--purple2)' },
                { val: pendingCount, label: 'En attente', sub: 'À traiter', color: 'var(--yellow)' },
                { val: '94%', label: 'Satisfaction estimée', sub: '+2% ce mois', color: 'var(--green)' },
                { val: '11h', label: 'Temps économisé', sub: 'Cette semaine', color: 'var(--text2)' },
              ].map(s => (
                <div key={s.label} style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: '10px', padding: '16px' }}>
                  <div style={{ fontSize: '28px', fontWeight: 600, color: s.color }}>{s.val}</div>
                  <div style={{ fontSize: '13px', fontWeight: 500, marginTop: '4px' }}>{s.label}</div>
                  <div style={{ fontSize: '11px', color: 'var(--text3)', marginTop: '2px' }}>{s.sub}</div>
                </div>
              ))}
            </div>

            <div style={{ fontSize: '13px', fontWeight: 500, marginBottom: '12px', color: 'var(--text2)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Répartition par réseau</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px', marginBottom: '24px' }}>
              {[
                { name: 'Instagram', count: 7, color: '#E1306C' },
                { name: 'TikTok', count: 3, color: '#ff0050' },
                { name: 'YouTube', count: 2, color: '#FF0000' },
              ].map(p => (
                <div key={p.name} style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: '10px', padding: '14px' }}>
                  <div style={{ fontSize: '20px', fontWeight: 600 }}>{p.count}</div>
                  <div style={{ fontSize: '13px', color: p.color, marginTop: '2px' }}>{p.name}</div>
                  <div style={{ height: '3px', background: 'var(--border)', borderRadius: '2px', marginTop: '8px', overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: `${(p.count/12)*100}%`, background: p.color, borderRadius: '2px' }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  )
}
