'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function Home() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)

  return (
    <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '40px 20px', background: 'var(--bg)' }}>
      {/* Background glow */}
      <div style={{ position: 'fixed', top: '10%', left: '50%', transform: 'translateX(-50%)', width: '600px', height: '600px', background: 'radial-gradient(circle, rgba(124,111,224,0.08) 0%, transparent 70%)', pointerEvents: 'none', zIndex: 0 }} />

      <div style={{ position: 'relative', zIndex: 1, maxWidth: '680px', width: '100%', textAlign: 'center' }}>
        {/* Badge */}
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', background: 'var(--purple-bg)', border: '1px solid var(--purple-border)', borderRadius: '20px', padding: '6px 16px', fontSize: '13px', color: 'var(--purple2)', marginBottom: '32px' }}>
          <span style={{ width: '6px', height: '6px', background: 'var(--green)', borderRadius: '50%', display: 'inline-block' }} />
          Agent IA actif — Propulsé par Claude
        </div>

        {/* Title */}
        <h1 style={{ fontSize: 'clamp(36px, 6vw, 60px)', fontWeight: 600, lineHeight: 1.1, marginBottom: '20px', letterSpacing: '-0.03em' }}>
          Votre manager IA
          <br />
          <span style={{ background: 'linear-gradient(135deg, #7c6fe0, #a78bfa)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            pour les réseaux sociaux
          </span>
        </h1>

        <p style={{ fontSize: '18px', color: 'var(--text2)', lineHeight: 1.7, marginBottom: '48px', maxWidth: '480px', margin: '0 auto 48px' }}>
          L&apos;IA lit vos messages Instagram, YouTube et TikTok, répond à votre place et crée du contenu dans votre style. Vous n&apos;avez plus rien à faire.
        </p>

        {/* Features */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px', marginBottom: '48px' }}>
          {[
            { icon: '✉', title: 'Répond aux DMs', desc: 'Dans votre ton, votre style' },
            { icon: '✦', title: 'Crée vos posts', desc: 'Instagram, TikTok, YouTube' },
            { icon: '⚡', title: 'Disponible 24h/24', desc: 'Jamais de message sans réponse' },
          ].map((f) => (
            <div key={f.title} style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '20px 16px' }}>
              <div style={{ fontSize: '22px', marginBottom: '8px' }}>{f.icon}</div>
              <div style={{ fontSize: '14px', fontWeight: 500, marginBottom: '4px' }}>{f.title}</div>
              <div style={{ fontSize: '12px', color: 'var(--text2)' }}>{f.desc}</div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <button
          onClick={() => { setLoading(true); router.push('/setup') }}
          style={{ background: 'var(--purple)', color: 'white', border: 'none', borderRadius: 'var(--radius)', padding: '16px 40px', fontSize: '16px', fontWeight: 500, cursor: 'pointer', width: '100%', maxWidth: '320px', transition: 'opacity 0.2s' }}
          onMouseEnter={e => (e.currentTarget.style.opacity = '0.88')}
          onMouseLeave={e => (e.currentTarget.style.opacity = '1')}
        >
          {loading ? 'Chargement...' : 'Commencer gratuitement →'}
        </button>

        <p style={{ fontSize: '12px', color: 'var(--text3)', marginTop: '16px' }}>
          Aucune carte de crédit • Installation en 2 minutes
        </p>
      </div>
    </main>
  )
}
