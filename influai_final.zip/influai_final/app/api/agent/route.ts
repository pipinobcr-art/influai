import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { message, sender, platform, config, action } = body

    if (!config?.apiKey) {
      return NextResponse.json({ error: 'Clé API manquante' }, { status: 400 })
    }

    const client = new Anthropic({ apiKey: config.apiKey })

    let prompt = ''

    if (action === 'reply') {
      prompt = `Tu es le manager IA de ${config.name}, un(e) influenceur(se) ${config.niche} avec un style de communication "${config.tone}".

Description de ${config.name} : ${config.bio || 'Influenceur lifestyle'}

Tu dois écrire une réponse personnelle et authentique au message suivant reçu sur ${platform} de @${sender} :

"${message}"

RÈGLES STRICTES :
- Écris comme si tu ÉTAIS ${config.name}, pas comme un assistant
- Ton : ${config.tone}
- Maximum 3-4 phrases, naturel, humain
- Adapte au contexte ${platform} (DM = intime, commentaire = public)
- Pas de guillemets, pas d'introduction, juste la réponse
- Si c'est une demande de colla/partenariat : sois chaleureux mais dis de contacter via l'email pro
- Si c'est une question sur un produit/lien : propose d'aller voir la bio
- Ajoute 1-2 emojis si approprié

Réponds directement :`

    } else if (action === 'generate_content') {
      const { contentType, platform: plt, idea, style } = body
      prompt = `Tu es le créateur de contenu IA de ${config.name}, influenceur(se) ${config.niche}.

Style de voix : ${style || config.tone}
Plateforme : ${plt}
Type de contenu : ${contentType}
Idée de base : ${idea}

Génère le contenu complet, prêt à poster. Adapte le format à ${plt} :
- Instagram : légende 150-250 mots + 5-8 hashtags pertinents
- TikTok : description courte 50-100 mots + 3-5 hashtags + hook de début de vidéo suggéré
- YouTube : description 200-350 mots + titre accrocheur suggéré + tags

Style : ${config.name} parle à la première personne, ton ${config.tone}, authentique.
Commence directement par le contenu, sans introduction.`

    } else if (action === 'analyze_message') {
      prompt = `Analyse ce message reçu sur ${platform} et catégorise-le.

Message de @${sender} : "${message}"

Réponds UNIQUEMENT en JSON sans markdown, sans backticks :
{"category":"dm_question|collaboration|spam|fan_positive|complaint|media_press|other","priority":"high|medium|low","requiresManualReview":true|false,"reason":"courte explication","suggestedAction":"reply_auto|reply_manual|ignore|alert_influencer"}`
    }

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      messages: [{ role: 'user', content: prompt }]
    })

    const text = response.content[0].type === 'text' ? response.content[0].text : ''
    return NextResponse.json({ result: text })

  } catch (err: unknown) {
    const error = err as Error
    return NextResponse.json({ error: error.message || 'Erreur serveur' }, { status: 500 })
  }
}
