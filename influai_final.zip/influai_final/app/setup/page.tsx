'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

const platforms = [
  { id: 'instagram', label: 'Instagram', color: '#E1306C', icon: '📸', desc: 'DMs, commentaires, stories' },
  { id: 'tiktok', label: 'TikTok', color: '#ff0050', icon: '🎵', desc: 'Commentaires, DMs, duos' },
  { id: 'youtube', label: 'YouTube', color: '#FF0000', icon: '▶', desc: 'Commentaires, membres, DMs' },
]

const tones = ['Chaleureux & proche', 'Professionnel', 'Fun & décalé', 'Inspirant', 'Expert', 'Décontracté']

export default function Setup() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [name, setName] = useState('')
  const [handle, setHandle] = useState('')
  const [niche, setNiche] = useState('')
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([])
  const [selectedTone, setSelectedTone] = useState('')
  const [bio, setBio] = useState('')
  const [apiKey, setApiKey] = useState('')
  const [saving, setSaving] = useState(false)

  function togglePlatform(id: string) {
    setSelectedPlatforms(prev => prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id])
  }

  async function finish() {
    setSaving(true)
    const config = { name, handle, niche, platforms: selectedPlatforms, tone: selectedTone, bio, apiKey }
    localStorage.setItem('influai_config', JSON.stringify(config))
    await new Promise(r => setTimeout(r, 800))
    router.push('/dashboard')
  }

  const cardStyle = {
    background: 'var(--bg2)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius)',
    padding: '32px',
    maxWidth: '560px',
    width: '100%',
  }

  const inputStyle = {
    width: '100%',
    background: 'var(--bg3)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius-sm)',
    padding: '12px 14px',
    fontSize: '14px',
    color: 'var(--text)',
    outline: 'none',
    fontFamily: 'inherit',
  }

  const btnPrimary = {
    background: 'var(--purple)',
    color: 'white',
    border: 'none',
    borderRadius: 'var(--radius-sm)',
    padding: '12px 24px',
    fontSize: '14px',
    fontWeight: 500,
    cursor: 'pointer',
    width: '100%',
  }

  return (
    <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '40px 20px', background: 'var(--bg)' }}>
      {/* Progress bar */}
      <div style={{ maxWidth: '560px', width: '100%', marginBottom: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
          <span style={{ fontSize: '13px', color: 'var(--text2)' }}>Étape {step} / 3</span>
          <span style={{ fontSize: '13px', color: 'var(--text2)' }}>{Math.round((step/3)*100)}%</span>
        </div>
        <div style={{ height: '3px', background: 'var(--border)', borderRadius: '2px', overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${(step/3)*100}%`, background: 'var(--purple)', borderRadius: '2px', transition: 'width 0.4s ease' }} />
        </div>
      </div>

      <div style={cardStyle}>
        {/* Step 1: Profile */}
        {step === 1 && (
          <div>
            <h2 style={{ fontSize: '22px', fontWeight: 600, marginBottom: '8px' }}>Votre profil influenceur</h2>
            <p style={{ color: 'var(--text2)', fontSize: '14px', marginBottom: '28px' }}>L&apos;IA va apprendre qui vous êtes pour vous ressembler parfaitement.</p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div>
                <label style={{ fontSize: '13px', color: 'var(--text2)', display: 'block', marginBottom: '6px' }}>Votre prénom / nom d&apos;influenceur</label>
                <input style={inputStyle} value={name} onChange={e => setName(e.target.value)} placeholder="Ex: Sophie Laurent" />
              </div>
              <div>
                <label style={{ fontSize: '13px', color: 'var(--text2)', display: 'block', marginBottom: '6px' }}>Votre pseudo principal</label>
                <input style={inputStyle} value={handle} onChange={e => setHandle(e.target.value)} placeholder="@sophielaurent" />
              </div>
              <div>
                <label style={{ fontSize: '13px', color: 'var(--text2)', display: 'block', marginBottom: '6px' }}>Votre niche / thématique</label>
                <input style={inputStyle} value={niche} onChange={e => setNiche(e.target.value)} placeholder="Ex: Lifestyle, fitness, beauté, cuisine, voyage..." />
              </div>
              <div>
                <label style={{ fontSize: '13px', color: 'var(--text2)', display: 'block', marginBottom: '6px' }}>Décrivez votre style en quelques mots</label>
                <textarea
                  style={{ ...inputStyle, height: '90px', resize: 'none', lineHeight: 1.6 }}
                  value={bio}
                  onChange={e => setBio(e.target.value)}
                  placeholder="Ex: Je suis une maman active de 28 ans qui partage sa vie saine, mes recettes et mes astuces beauté. Ma communauté est proche et fidèle..."
                />
              </div>
            </div>

            <button style={{ ...btnPrimary, marginTop: '24px' }} onClick={() => name && setStep(2)} disabled={!name}>
              Continuer →
            </button>
          </div>
        )}

        {/* Step 2: Platforms & Tone */}
        {step === 2 && (
          <div>
            <h2 style={{ fontSize: '22px', fontWeight: 600, marginBottom: '8px' }}>Réseaux & style de communication</h2>
            <p style={{ color: 'var(--text2)', fontSize: '14px', marginBottom: '24px' }}>L&apos;IA adaptera son style à chaque plateforme.</p>

            <div style={{ marginBottom: '24px' }}>
              <label style={{ fontSize: '13px', color: 'var(--text2)', display: 'block', marginBottom: '12px' }}>Vos réseaux actifs</label>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {platforms.map(p => (
                  <div
                    key={p.id}
                    onClick={() => togglePlatform(p.id)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: '14px',
                      padding: '14px 16px', borderRadius: 'var(--radius-sm)', cursor: 'pointer',
                      border: selectedPlatforms.includes(p.id) ? `1px solid ${p.color}40` : '1px solid var(--border)',
                      background: selectedPlatforms.includes(p.id) ? `${p.color}10` : 'var(--bg3)',
                      transition: 'all 0.15s',
                    }}
                  >
                    <span style={{ fontSize: '22px' }}>{p.icon}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '14px', fontWeight: 500 }}>{p.label}</div>
                      <div style={{ fontSize: '12px', color: 'var(--text2)' }}>{p.desc}</div>
                    </div>
                    <div style={{
                      width: '20px', height: '20px', borderRadius: '50%',
                      border: selectedPlatforms.includes(p.id) ? 'none' : '1px solid var(--border2)',
                      background: selectedPlatforms.includes(p.id) ? 'var(--green)' : 'transparent',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px'
                    }}>
                      {selectedPlatforms.includes(p.id) && '✓'}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div style={{ marginBottom: '24px' }}>
              <label style={{ fontSize: '13px', color: 'var(--text2)', display: 'block', marginBottom: '12px' }}>Votre ton de communication</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {tones.map(t => (
                  <button
                    key={t}
                    onClick={() => setSelectedTone(t)}
                    style={{
                      padding: '8px 14px', borderRadius: '20px', fontSize: '13px', cursor: 'pointer',
                      border: selectedTone === t ? '1px solid var(--purple)' : '1px solid var(--border)',
                      background: selectedTone === t ? 'var(--purple-bg)' : 'transparent',
                      color: selectedTone === t ? 'var(--purple2)' : 'var(--text2)',
                    }}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <button style={{ ...btnPrimary, background: 'var(--bg3)', color: 'var(--text2)', border: '1px solid var(--border)' }} onClick={() => setStep(1)}>← Retour</button>
              <button style={btnPrimary} onClick={() => selectedPlatforms.length > 0 && setStep(3)} disabled={selectedPlatforms.length === 0}>Continuer →</button>
            </div>
          </div>
        )}

        {/* Step 3: API Key */}
        {step === 3 && (
          <div>
            <h2 style={{ fontSize: '22px', fontWeight: 600, marginBottom: '8px' }}>Clé API Anthropic</h2>
            <p style={{ color: 'var(--text2)', fontSize: '14px', marginBottom: '24px' }}>
              L&apos;IA utilise Claude pour générer les réponses. Vous avez besoin d&apos;une clé API gratuite.
            </p>

            <div style={{ background: 'var(--purple-bg)', border: '1px solid var(--purple-border)', borderRadius: 'var(--radius-sm)', padding: '16px', marginBottom: '20px', fontSize: '13px', color: 'var(--text2)', lineHeight: 1.7 }}>
              <strong style={{ color: 'var(--purple2)' }}>Comment obtenir votre clé :</strong><br />
              1. Allez sur <a href="https://console.anthropic.com" target="_blank" style={{ color: 'var(--purple2)' }}>console.anthropic.com</a><br />
              2. Créez un compte gratuit<br />
              3. Cliquez sur &quot;API Keys&quot; → &quot;Create Key&quot;<br />
              4. Copiez-collez la clé ici
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ fontSize: '13px', color: 'var(--text2)', display: 'block', marginBottom: '6px' }}>Votre clé API Anthropic</label>
              <input
                style={{ ...inputStyle, fontFamily: 'monospace', fontSize: '13px' }}
                type="password"
                value={apiKey}
                onChange={e => setApiKey(e.target.value)}
                placeholder="sk-ant-api03-..."
              />
            </div>

            <div style={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '12px 14px', marginBottom: '20px', fontSize: '12px', color: 'var(--text3)' }}>
              🔒 Votre clé est stockée uniquement dans votre navigateur. Elle n&apos;est jamais envoyée sur un serveur tiers.
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <button style={{ ...btnPrimary, background: 'var(--bg3)', color: 'var(--text2)', border: '1px solid var(--border)' }} onClick={() => setStep(2)}>← Retour</button>
              <button style={{ ...btnPrimary, opacity: saving ? 0.7 : 1 }} onClick={finish} disabled={!apiKey || saving}>
                {saving ? 'Configuration...' : '🚀 Lancer mon IA →'}
              </button>
            </div>
          </div>
        )}
      </div>
    </main>
  )
}
