import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'InfluAI — Manager IA pour Influenceurs',
  description: 'L\'IA qui gère vos réseaux sociaux à votre place',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  )
}
